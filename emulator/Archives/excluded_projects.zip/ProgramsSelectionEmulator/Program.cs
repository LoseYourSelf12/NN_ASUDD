﻿//using clProgramSelection;
using clProgramSelection;
using clProgramSelectionDotNet48;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//using static clProgramSelection.ProgramSelection;

namespace clProgramSelection //ProgramsSelectionEmulator
{
    class Program
    {
        private static Dictionary<int, List<ProgramSelectionDotNet48.ProgramDiapason>> InitializeTrafficLightsPrograms(int detectorsCount)
        {
            Dictionary<int, List<ProgramSelectionDotNet48.ProgramDiapason>> dTrafficLightsPrograms = new Dictionary<int, List<ProgramSelectionDotNet48.ProgramDiapason>>();

            List<ProgramSelectionDotNet48.ProgramDiapason> progList; 
            ProgramSelectionDotNet48.ProgramDiapason program;

            //Каждый такой блок соответствует строке в таблице "Значения интенсивности транспортного потока":
            progList = new List<ProgramSelectionDotNet48.ProgramDiapason>();
            
            for (int i = 0; i < detectorsCount; i++)
            {
                program = new ProgramSelectionDotNet48.ProgramDiapason();
                program.bCheck = true;
                program.fromIntense = 0;
                program.toIntense = 900;
                progList.Add(program);
            }
            dTrafficLightsPrograms.Add(4, progList); 

            progList = new List<ProgramSelectionDotNet48.ProgramDiapason>();
            for (int i = 0; i < detectorsCount; i++)
            {
                program = new ProgramSelectionDotNet48.ProgramDiapason();
                program.bCheck = true;
                program.fromIntense = 800;
                program.toIntense = 1000;
                progList.Add(program);
            }
            dTrafficLightsPrograms.Add(5, progList);
            
            progList = new List<ProgramSelectionDotNet48.ProgramDiapason>();
            for (int i = 0; i < detectorsCount; i++)
            {
                program = new ProgramSelectionDotNet48.ProgramDiapason();
                program.bCheck = true;
                if (i == 0) program.bCheck = false;
                program.fromIntense = 1000;
                program.toIntense = 1200;
                progList.Add(program);
            }
            dTrafficLightsPrograms.Add(6, progList);

            progList = new List<ProgramSelectionDotNet48.ProgramDiapason>();
            for (int i = 0; i < detectorsCount; i++)
            {
                program = new ProgramSelectionDotNet48.ProgramDiapason();
                program.bCheck = false;
                if (i == 3) program.bCheck = true;
                program.fromIntense = 0;
                program.toIntense = 1111;
                progList.Add(program);
            }
            dTrafficLightsPrograms.Add(10, progList);

            progList = new List<ProgramSelectionDotNet48.ProgramDiapason>();
            for (int i = 0; i < detectorsCount; i++)
            {
                program = new ProgramSelectionDotNet48.ProgramDiapason();
                program.bCheck = true;
               // if (i == 2) program.bCheck = false;
                program.fromIntense = 900;
                program.toIntense = 2000;
                progList.Add(program);
            }
            dTrafficLightsPrograms.Add(14, progList);

            progList = new List<ProgramSelectionDotNet48.ProgramDiapason>();
            for (int i = 0; i < detectorsCount; i++)
            {
                program = new ProgramSelectionDotNet48.ProgramDiapason();
                program.bCheck = false;
                program.fromIntense = 0;
                program.toIntense = 0;
                progList.Add(program);                
            }
            dTrafficLightsPrograms.Add(15, progList);
            
            return dTrafficLightsPrograms;
        }
        //PRGRM:12=4[1:0-800;1][2:0-800;1][3:0-800;0]
        private static Dictionary<int, List<ProgramSelectionDotNet48.ProgramDiapason>> InitializeTrafficLightsProgramsREAL(int detectorsCount)
        {
            Dictionary<int, List<ProgramSelectionDotNet48.ProgramDiapason>> dTrafficLightsPrograms = new Dictionary<int, List<ProgramSelectionDotNet48.ProgramDiapason>>();

            List<ProgramSelectionDotNet48.ProgramDiapason> progList;
            ProgramSelectionDotNet48.ProgramDiapason program;

            //Каждый такой блок соответствует строке в таблице "Значения интенсивности транспортного потока":
            progList = new List<ProgramSelectionDotNet48.ProgramDiapason>();
            for (int i = 0; i < detectorsCount; i++)
            {
                program = new ProgramSelectionDotNet48.ProgramDiapason();
                program.bCheck = true;
                program.fromIntense = 0;
                program.toIntense = 900;
                progList.Add(program);
            }
            dTrafficLightsPrograms.Add(1, progList);

            progList = new List<ProgramSelectionDotNet48.ProgramDiapason>();
            for (int i = 0; i < detectorsCount; i++)
            {
                program = new ProgramSelectionDotNet48.ProgramDiapason();
                program.bCheck = true;
                program.fromIntense = 800;
                program.toIntense = 1000;
                progList.Add(program);
            }
            dTrafficLightsPrograms.Add(2, progList);       

            return dTrafficLightsPrograms;
        }
        private static Dictionary<int, List<int>> InitializeDetectorValues(int detectorsCount)
        {
            Dictionary<int, List<int>> detectorsValues = new Dictionary<int, List<int>>();
            //Номер детектора
            int i = 0;

            List<int> cycleDetectValues = new List<int>();
            cycleDetectValues.Add(600); cycleDetectValues.Add(901); cycleDetectValues.Add(1050); cycleDetectValues.Add(965);
            detectorsValues.Add(i, cycleDetectValues);
            Console.WriteLine($"Значения циклов для детектора - {i}:");
            Console.WriteLine(String.Join("|", cycleDetectValues));
            i++;

            cycleDetectValues = new List<int>();
            cycleDetectValues.Add(800); cycleDetectValues.Add(713); cycleDetectValues.Add(1165); cycleDetectValues.Add(541);
            detectorsValues.Add(i, cycleDetectValues);
            Console.WriteLine($"Значения циклов для детектора - {i}:");
            Console.WriteLine(String.Join("|", cycleDetectValues));
            i++;

            cycleDetectValues = new List<int>();
            cycleDetectValues.Add(1000); cycleDetectValues.Add(1059); cycleDetectValues.Add(360); cycleDetectValues.Add(1138);
            detectorsValues.Add(i, cycleDetectValues);
            Console.WriteLine($"Значения циклов для детектора - {i}:");
            Console.WriteLine(String.Join("|", cycleDetectValues));
            i++;
            return detectorsValues;
        }

        //const int detObjectsCount = 3;

        //struct struct1
        //{
        //    public int neuro;
        //    public int DIL;
        //}

        static void Main(string[] args)
        {
            //создаём экземпляр класса ProgramSelection - для выбора программы
            ProgramSelectionDotNet48 ps = new ProgramSelectionDotNet48();


            //Dictionary<ProgramSelection.ProgramListKey, List<ProgramSelection.ProgramDiapason>> trafficLightsPrograms;
            //trafficLightsPrograms = ps.ImportTrafficLightsProgramsFromFile("d:\\TrafficLightsProgram.txt"); // ProgramSelection.GetExeDirectory() + 

            //Вариант заполнения программ светофоров trafficLightsPrograms, муляж - InitializeTrafficLightsPrograms(detectorsCount);
            List<string> neuroValuesStringsRMC = new List<string>();
            //neuroValuesStringsRMC.Add("@RMC:11{CTL:17:20:15> DIL:17:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}5");
            //neuroValuesStringsRMC.Add("@RMC:11{CTL:17:20:20> DIL:17:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}8:5\n\r");
            //neuroValuesStringsRMC.Add("@RMC:11{CTL:17:20:30> DIL:17:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}10\n\r");
            //neuroValuesStringsRMC.Add("@RMC:11{CTL:18:20:15> DIL:18:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}4");
            //neuroValuesStringsRMC.Add("@RMC:11{CTL:18:20:20> DIL:18:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}7:5\n\r");
            //neuroValuesStringsRMC.Add("@RMC:11{CTL:19:20:30> DIL:18:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}9\n\r");
            //neuroValuesStringsRMC.Add("@RMC:22{CTL:17:20:15> DIL:17:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}5");
            //neuroValuesStringsRMC.Add("@RMC:22{CTL:18:20:20> DIL:17:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}8:5\n\r");
            //neuroValuesStringsRMC.Add("@RMC:22{CTL:18:20:30> DIL:17:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}10\n\r");
            //neuroValuesStringsRMC.Add("@RMC:22{CTL:18:20:15> DIL:18:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}4");
            //neuroValuesStringsRMC.Add("@RMC:22{CTL:19:20:20> DIL:18:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}7:5\n\r");
            //neuroValuesStringsRMC.Add("@RMC:22{CTL:19:20:30> DIL:18:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}9\n\r");

            neuroValuesStringsRMC.Add("@RMC:11{CTL:17:20:15> DIL:17:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}5");
            neuroValuesStringsRMC.Add("@RMC:11{CTL:17:20:20> DIL:17:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}8:5\n\r");
            neuroValuesStringsRMC.Add("@RMC:11{CTL:17:20:30> DIL:17:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}10\n\r");
            neuroValuesStringsRMC.Add("@RMC:11{CTL:18:21:15> DIL:18:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}4");
            neuroValuesStringsRMC.Add("@RMC:11{CTL:18:22:20> DIL:18:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}7:5\n\r");
            neuroValuesStringsRMC.Add("@RMC:11{CTL:18:23:30> DIL:18:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}9\n\r");

            //neuroValuesStringsRMC.Add("@RMC134536363");

            neuroValuesStringsRMC.Add("@RMC:12{CTL:20:24:15> DIL:18:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}5");
            neuroValuesStringsRMC.Add("@RMC:13{CTL:20:25:20> DIL:18:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}8:5\n\r");
            neuroValuesStringsRMC.Add("@RMC:14{CTL:19:20:30> DIL:19:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}10\n\r");
            neuroValuesStringsRMC.Add("@RMC:15{CTL:19:21:15> DIL:19:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}4");
            neuroValuesStringsRMC.Add("@RMC:16{CTL:19:22:20> DIL:19:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}7:5\n\r");
            neuroValuesStringsRMC.Add("@RMC:17{CTL:19:23:30> DIL:19:ул.Сивки_к_ТЦ_‘Хромая_лошадь’:T1}9\n\r");

            ////= new Dictionary<int, List<ProgramSelection.DetectorMeasuring>>();
            //List<ProgramSelection.DetectorMeasuring> detectorsValues;
            //detectorsValues = ps.GetNeurodetectorsValuesFromList(neuroValuesStringsRMC); //ProgramSelection.InitializeDetectorValues(detectorsCount);

            ////List<double> averageValuesList = null;
            //Dictionary<int, double> averageValuesDict = null;

            ////Console.Write("Введите '0', если нужно использовать средневзвешенные значения: ");
            ////if (Console.ReadLine().Trim() == "0")
            ////{
            ////    Console.Write("Введите шаг средневзешенного веса: "); string usStr = Console.ReadLine();
            ////    double weightStep = Convert.ToDouble(usStr);
            ////    //Получаем список средневзвешенных
            ////    averageValuesList = ProgramSelection.GetWeightedAverageList(detectorValues, detectorsCount, weightStep);

            ////    Console.WriteLine("Средниевзвешенные значения интенсивностей:");
            ////    Console.WriteLine(String.Join(" | ", averageValuesList));
            ////}
            ////else
            ////{
            ////Получаем список средних - В ТОМ ПОРЯДКЕ В КОТОРОМ ОНИ БЫЛИ В neuroValuesStringsRMC
            ////averageValuesList = ps.GetArithmeticMeanList(detectorsValues);
            ////Console.WriteLine("Средние значения интенсивностей:");
            ////Console.WriteLine(String.Join(" | ", averageValuesList));

            ////Получаем список средних - В ТОМ ПОРЯДКЕ В КОТОРОМ ОНИ БЫЛИ В neuroValuesStringsRMC
            //// KeyValuePair<НомерДетОбъекта, СредееЗначение>
            //averageValuesDict = ps.GetArithmeticMean_Dict_IdOb_Aver(detectorsValues);
            //if (averageValuesDict.Count > 0)
            //{ 
            //    Console.WriteLine("Средние значения интенсивностей:");
            //    foreach (var MeanKeyAverValue in averageValuesDict)
            //    {
            //        Console.WriteLine($" №дет.объекта: {MeanKeyAverValue.Key}; Среднее - {MeanKeyAverValue.Value}");
            //    }
            //}
            //else { Console.WriteLine("Нет средних значений интенсивностей!"); }

            ////Ищем подходящие программы:            
            //if (trafficLightsPrograms.Count > 0 && averageValuesDict.Count > 0) { Console.WriteLine("Список подходящих программ (по номерам):"); }
            ////Для случая когда каждому нейродетектору соответствует свой список подходящих программ
            ////Dictionary<int, List<int>> suitableProgramsDict = ps.GetSuitableProgramsDict(trafficLightsPrograms, averageValuesDict);

            ////!!!ПОЛУЧАЕМ СПИСОК ПОДХОДЯЩИХ ПРОГРАММ
            //List<int> suitableProgramsList = ps.GetSuitableProgramsList(trafficLightsPrograms, averageValuesDict);

            ////для случая использования id_n нейродетекторов:
            ////foreach (var keyVal in suitableProgramsList)
            ////{
            ////    Console.WriteLine($"№детектора: {keyVal.Key}, №№ программ: {String.Join(" | ", (List<int>)keyVal.Value)}; ");
            ////}
            //Console.WriteLine(String.Join(" | ", suitableProgramsList));

            ps.GetIntensitiesForNow(neuroValuesStringsRMC, "dan", "xuBdyEF20", "" , "AverIntensities.intens");
            ps.ChooseProgramTZPP(neuroValuesStringsRMC, "dan", "xuBdyEF20", @"C:\", @"TrafficLightsProgram.cnf");

            //if (suitableProgramsList.Count > 0)
            //{
            //    //Console.WriteLine("Выбираем программу из списка:");
            //    //Console.WriteLine(ps.GetChoosenProgram(suitableProgramsList));
                
            //}

            //для случая использования id_n нейродетекторов:
            //Dictionary<int, int> choosenProgramDict = ps.GetChoosenProgramsForEveryDetector(suitableProgramsDict);
            //if (choosenProgramDict.Count > 0) { Console.WriteLine("Подходящие программы не найдены!"); }
            //foreach (var keyVal in choosenProgramDict)
            //{
            //    Console.WriteLine($"№детектора: {keyVal.Key}, № выбранной программы: {keyVal.Value}; ");
            //}    

            ////ВЫЗОВ ГЛАВНОЙ ПОДПРОГРАММЫ:
            //ps.ChooseProgramFull("D:\\TrafficLightsProgram.txt", neuroValuesStri0ngsRMC, 3);

            Console.ReadLine();

        }
}  
}
