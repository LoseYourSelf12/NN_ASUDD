﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tryCLProgramSelection
{
    public class tryClass
    {
        public int Sumsum(int a, int b)
        { return 0; }
    }
}
