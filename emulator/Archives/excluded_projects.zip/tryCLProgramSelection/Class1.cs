﻿namespace tryCLProgramSelection
{
    public class Class1
    {

    }
}