﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace libProgramSelection
//{
//    public class ProgramSelection
//    {
//        public struct Program
//        {
//            public bool bCheck { get; set; }
//            public int fromIntense { get; set; }
//            public int toIntense { get; set; }
//        }
//        /// <summary>
//        /// Получить средневзвешенное значение по словарю интенсивностей и количеству детекторов
//        /// </summary>
//        /// <param name="detectorValues"> Словарь интенсивностей, ключ - номер цикла </param>
//        /// <param name="detectorCount"> Количество детекторов </param>
//        /// <param name="weightStep"></param>
//        /// <returns></returns>
//        public static List<double> GetWeightedAverageList(Dictionary<int, List<int>> detectorValues, int detectorCount, double weightStep)
//        {
//            List<double> listWeightedMeans = new List<double>();
           
//            //Добавляем новые элементы в список, в количестве detectorCount
//            for (int i = 0; i < detectorCount; i++)
//            {
//                listWeightedMeans.Add(0);
//            }

//            //вычисляем начальный вес 
//            double curWeight = weightStep * detectorValues.Count;
//            double weightsSum = 0;
//            foreach (var listDetectorValues in detectorValues)
//            //for (int i=0; i < detectorValues.Count; i++)
//            {
//                List<int> list = listDetectorValues.Value;
//                weightsSum += curWeight;
//                for (int j = 0; j < list.Count; j++)
//                {                    
//                    listWeightedMeans[j] += (list[j] * curWeight);                   
//                }
//                curWeight -= weightStep;
//            }

//            for (int i = 0; i < listWeightedMeans.Count; i++)
//            {
//                listWeightedMeans[i] = listWeightedMeans[i] / weightsSum;
//            }

//            return listWeightedMeans;
//        }

//        /// <summary>
//        /// Вычислить среднее значение по словарю интенсивностей и количеству детекторов
//        /// </summary>
//        /// <param name="detectorValues">Словарь интенсивностей, ключ - номер цикла </param>
//        /// <param name="detectorCount">Количество детекторов</param>
//        /// <returns></returns>
//        public static List<double> GetArithmeticMeanList(Dictionary<int, List<int>> detectorValues, int detectorCount)
//        {
//            // detectorValues.Count - строк в таблице
//            // detectorCount - столбцов в таблице

//            List<double> listArithMeans = new List<double>();

//            //Добавляем новые элементы в список, в количестве detectorCount
//            for (int i = 0; i < detectorCount; i++)
//            {
//                listArithMeans.Add(0);
//            }

//            foreach (var listDetectorValues in detectorValues)
//            //for (int i=0; i < detectorValues.Count; i++)
//            {
//                List<int> list = listDetectorValues.Value;
//                for (int j = 0; j < list.Count; j++)
//                {
//                    listArithMeans[j] += list[j];
//                }
//            }

//            for (int i = 0; i < listArithMeans.Count; i++)
//            {
//                listArithMeans[i] = listArithMeans[i] / detectorValues.Count;
//            }

//            return listArithMeans;
//        }

//        /// <summary>
//        /// Получить список подходящих программ 
//        /// </summary>
//        /// <param name="trafficLightsPrograms"> Список программ светофоров , доступ - по номеру </param>
//        /// <param name="averageValuesList"> "Усреднённые значения интенсивностей, для которых выбирается программа"</param>
//        /// <returns></returns>
//        public static List<int> GetSuitableProgramsList(Dictionary<int, List<ProgramSelection.Program>> trafficLightsPrograms, List<double> averageValuesList)
//        {
//            List<int> resList = new List<int>();
//            int i ;
//            bool isCommonMatch;
//            bool isCurMatch ;
//            bool bAreWorkingPrograms;
//            foreach (var curTrProgramList in trafficLightsPrograms)
//            {
//                i = 0;
//                //Здесь берём де-факто true, просто страховка от пустого списка
//                isCommonMatch = (curTrProgramList.Value.Count > 0);
//                bAreWorkingPrograms = false;
//                foreach (var Program in curTrProgramList.Value)
//                {
//                    // Это чтобы отбросить тот случай, когда везде НЕ проставлен флаг проверки
//                    bAreWorkingPrograms = bAreWorkingPrograms || Program.bCheck;
//                    isCurMatch = (!Program.bCheck ||
//                        (Program.fromIntense <= averageValuesList[i] &&  averageValuesList[i] < Program.toIntense));
                                    
//                    isCommonMatch = isCommonMatch && isCurMatch;                    
//                    i++;
//                    if (!isCommonMatch) break;
//                }
//                if (isCommonMatch && bAreWorkingPrograms) resList.Add(curTrProgramList.Key);                
//            }
//            return resList;
//        }

//        /// <summary>
//        /// Возвращает номер выбранной (из подходящих) программы
//        /// </summary>
//        /// <param name="suitableProgramsList"></param>
//        /// <returns></returns>
//        public static int GetChoosenProgram (List<int> suitableProgramsList)
//        {
//            //Здесь выбирается последняя программа
//            if (suitableProgramsList.Count > 0) { return suitableProgramsList[suitableProgramsList.Count-1]; }
//            else return 0;
//        }
//    }
//}
